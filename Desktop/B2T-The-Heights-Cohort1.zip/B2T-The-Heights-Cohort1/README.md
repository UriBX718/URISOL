# B2T-The-Heights-Cohort1
Now that you all have a GitHub, you should fork and clone this repository to always be up-to-date with the class materials and assignments!!
